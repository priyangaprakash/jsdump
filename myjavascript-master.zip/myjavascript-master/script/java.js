var a = prompt("what is your age??");
switch(a)
{
case 18:
alert("no right to vote");
break;
case 60:
alert("right to vote");
break;
default:
alert("default case");
break;
}
confirm("Coming to the end");
alert("OK, byeeeee!!");
